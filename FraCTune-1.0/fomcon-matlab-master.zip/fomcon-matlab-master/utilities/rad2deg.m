function deg = rad2deg(rad)
% RAD2DEG Convert radians to degrees.
	deg = rad./(pi/180);
end