function ct = ctrb(S)
%CTRB Controllability matrix for FOSS system

ct = ctrb(S.A,S.B);

end

