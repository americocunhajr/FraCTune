function G = fotf(S)
%FOTF Convert to FOTF

G = getfotf(S);

end

