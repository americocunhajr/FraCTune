function ob = obsv(S)
%OBSV Observability matrix for FOSS system

ob = obsv(S.a, S.c);

end

